class CNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  l1 : __torch__.torch.nn.modules.linear.Linear
  l2 : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  act : __torch__.torch.nn.modules.activation.ReLU
  pool : __torch__.torch.nn.modules.pooling.MaxPool2d
  def forward(self: __torch__.CNN,
    x: Tensor) -> Tensor:
    l2 = self.l2
    l1 = self.l1
    conv2 = self.conv2
    pool = self.pool
    act = self.act
    conv1 = self.conv1
    _0 = (act).forward((conv1).forward(x, ), )
    _1 = (conv2).forward((pool).forward(_0, ), )
    _2 = (pool).forward1((act).forward1(_1, ), )
    input = torch.flatten((pool).forward2(_2, ), 1)
    _3 = (act).forward2((l1).forward(input, ), )
    _4 = torch.softmax((l2).forward(_3, ), 1)
    return _4
