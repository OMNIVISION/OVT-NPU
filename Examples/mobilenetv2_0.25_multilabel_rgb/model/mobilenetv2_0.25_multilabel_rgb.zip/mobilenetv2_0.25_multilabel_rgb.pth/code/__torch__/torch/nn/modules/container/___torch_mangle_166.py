class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.container.Sequential
  __annotations__["1"] = __torch__.InvertedResidual
  __annotations__["2"] = __torch__.___torch_mangle_15.InvertedResidual
  __annotations__["3"] = __torch__.___torch_mangle_25.InvertedResidual
  __annotations__["4"] = __torch__.___torch_mangle_35.InvertedResidual
  __annotations__["5"] = __torch__.___torch_mangle_45.InvertedResidual
  __annotations__["6"] = __torch__.___torch_mangle_55.InvertedResidual
  __annotations__["7"] = __torch__.___torch_mangle_65.InvertedResidual
  __annotations__["8"] = __torch__.___torch_mangle_75.InvertedResidual
  __annotations__["9"] = __torch__.___torch_mangle_85.InvertedResidual
  __annotations__["10"] = __torch__.___torch_mangle_95.InvertedResidual
  __annotations__["11"] = __torch__.___torch_mangle_105.InvertedResidual
  __annotations__["12"] = __torch__.___torch_mangle_115.InvertedResidual
  __annotations__["13"] = __torch__.___torch_mangle_125.InvertedResidual
  __annotations__["14"] = __torch__.___torch_mangle_135.InvertedResidual
  __annotations__["15"] = __torch__.___torch_mangle_145.InvertedResidual
  __annotations__["16"] = __torch__.___torch_mangle_155.InvertedResidual
  __annotations__["17"] = __torch__.___torch_mangle_165.InvertedResidual
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_166.Sequential,
    x: Tensor) -> Tensor:
    _17 = getattr(self, "17")
    _16 = getattr(self, "16")
    _15 = getattr(self, "15")
    _14 = getattr(self, "14")
    _13 = getattr(self, "13")
    _12 = getattr(self, "12")
    _11 = getattr(self, "11")
    _10 = getattr(self, "10")
    _9 = getattr(self, "9")
    _8 = getattr(self, "8")
    _7 = getattr(self, "7")
    _6 = getattr(self, "6")
    _5 = getattr(self, "5")
    _4 = getattr(self, "4")
    _3 = getattr(self, "3")
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _18 = (_2).forward((_1).forward((_0).forward(x, ), ), )
    _19 = (_5).forward((_4).forward((_3).forward(_18, ), ), )
    _20 = (_8).forward((_7).forward((_6).forward(_19, ), ), )
    _21 = (_10).forward((_9).forward(_20, ), )
    _22 = (_12).forward((_11).forward(_21, ), )
    _23 = (_14).forward((_13).forward(_22, ), )
    _24 = (_16).forward((_15).forward(_23, ), )
    return (_17).forward(_24, )
