class MobileNetV2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  features : __torch__.torch.nn.modules.container.___torch_mangle_166.Sequential
  conv : __torch__.torch.nn.modules.container.___torch_mangle_170.Sequential
  avgpool : __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  classifier : __torch__.torch.nn.modules.linear.Linear
  sigmoid : __torch__.torch.nn.modules.activation.Sigmoid
  def forward(self: __torch__.MobileNetV2,
    x: Tensor) -> Tensor:
    sigmoid = self.sigmoid
    classifier = self.classifier
    avgpool = self.avgpool
    conv = self.conv
    features = self.features
    _0 = (conv).forward((features).forward(x, ), )
    _1 = (avgpool).forward(_0, )
    _2 = ops.prim.NumToTensor(torch.size(_1, 0))
    input = torch.view(_1, [int(_2), -1])
    _3 = (sigmoid).forward((classifier).forward(input, ), )
    return _3
class InvertedResidual(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.container.___torch_mangle_5.Sequential
  def forward(self: __torch__.InvertedResidual,
    argument_1: Tensor) -> Tensor:
    conv = self.conv
    input = torch.add(argument_1, (conv).forward(argument_1, ))
    return input
