class Flatten(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.flatten.___torch_mangle_11199.Flatten,
    argument_1: Tensor) -> Tensor:
    return torch.flatten(argument_1, 1)
