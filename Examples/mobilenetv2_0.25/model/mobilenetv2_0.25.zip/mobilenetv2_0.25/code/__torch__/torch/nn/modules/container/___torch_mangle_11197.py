class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.container.___torch_mangle_11029.Sequential
  __annotations__["1"] = __torch__.___torch_mangle_11036.InvertedResidual
  __annotations__["2"] = __torch__.___torch_mangle_11046.InvertedResidual
  __annotations__["3"] = __torch__.___torch_mangle_11056.InvertedResidual
  __annotations__["4"] = __torch__.___torch_mangle_11066.InvertedResidual
  __annotations__["5"] = __torch__.___torch_mangle_11076.InvertedResidual
  __annotations__["6"] = __torch__.___torch_mangle_11086.InvertedResidual
  __annotations__["7"] = __torch__.___torch_mangle_11096.InvertedResidual
  __annotations__["8"] = __torch__.___torch_mangle_11106.InvertedResidual
  __annotations__["9"] = __torch__.___torch_mangle_11116.InvertedResidual
  __annotations__["10"] = __torch__.___torch_mangle_11126.InvertedResidual
  __annotations__["11"] = __torch__.___torch_mangle_11136.InvertedResidual
  __annotations__["12"] = __torch__.___torch_mangle_11146.InvertedResidual
  __annotations__["13"] = __torch__.___torch_mangle_11156.InvertedResidual
  __annotations__["14"] = __torch__.___torch_mangle_11166.InvertedResidual
  __annotations__["15"] = __torch__.___torch_mangle_11176.InvertedResidual
  __annotations__["16"] = __torch__.___torch_mangle_11186.InvertedResidual
  __annotations__["17"] = __torch__.___torch_mangle_11196.InvertedResidual
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_11197.Sequential,
    input: Tensor) -> Tensor:
    _17 = getattr(self, "17")
    _16 = getattr(self, "16")
    _15 = getattr(self, "15")
    _14 = getattr(self, "14")
    _13 = getattr(self, "13")
    _12 = getattr(self, "12")
    _11 = getattr(self, "11")
    _10 = getattr(self, "10")
    _9 = getattr(self, "9")
    _8 = getattr(self, "8")
    _7 = getattr(self, "7")
    _6 = getattr(self, "6")
    _5 = getattr(self, "5")
    _4 = getattr(self, "4")
    _3 = getattr(self, "3")
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _18 = (_1).forward((_0).forward(input, ), )
    _19 = (_4).forward((_3).forward((_2).forward(_18, ), ), )
    _20 = (_7).forward((_6).forward((_5).forward(_19, ), ), )
    _21 = (_10).forward((_9).forward((_8).forward(_20, ), ), )
    _22 = (_12).forward((_11).forward(_21, ), )
    _23 = (_14).forward((_13).forward(_22, ), )
    _24 = (_16).forward((_15).forward(_23, ), )
    return (_17).forward(_24, )
