class Conv2d(Module):
  __parameters__ = ["weight", ]
  __buffers__ = []
  weight : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_11026.Conv2d,
    input: Tensor) -> Tensor:
    weight = self.weight
    input0 = torch._convolution(input, weight, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1, True, False, True, True)
    return input0
