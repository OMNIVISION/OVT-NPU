class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.container.___torch_mangle_166.Sequential
  __annotations__["1"] = __torch__.torch.nn.modules.pooling.AdaptiveAvgPool2d
  __annotations__["2"] = __torch__.torch.nn.modules.flatten.Flatten
  __annotations__["3"] = __torch__.torch.nn.modules.linear.Identity
  __annotations__["4"] = __torch__.torch.nn.modules.linear.Linear
  __annotations__["5"] = __torch__.torch.nn.modules.activation.Sigmoid
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_167.Sequential,
    input: Tensor) -> Tensor:
    _5 = getattr(self, "5")
    _4 = getattr(self, "4")
    _3 = getattr(self, "3")
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _6 = (_1).forward((_0).forward(input, ), )
    _7 = (_2).forward(_6, )
    _8 = (_3).forward()
    return (_5).forward((_4).forward(_7, ), )
