class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.torch.nn.modules.conv.___torch_mangle_86.Conv2d
  __annotations__["1"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_87.BatchNorm2d
  __annotations__["2"] = __torch__.torch.nn.modules.activation.___torch_mangle_88.ReLU6
  __annotations__["3"] = __torch__.torch.nn.modules.conv.___torch_mangle_89.Conv2d
  __annotations__["4"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_90.BatchNorm2d
  __annotations__["5"] = __torch__.torch.nn.modules.activation.___torch_mangle_91.ReLU6
  __annotations__["6"] = __torch__.torch.nn.modules.conv.___torch_mangle_92.Conv2d
  __annotations__["7"] = __torch__.torch.nn.modules.batchnorm.___torch_mangle_93.BatchNorm2d
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_94.Sequential,
    argument_1: Tensor) -> Tensor:
    _7 = getattr(self, "7")
    _6 = getattr(self, "6")
    _5 = getattr(self, "5")
    _4 = getattr(self, "4")
    _3 = getattr(self, "3")
    _2 = getattr(self, "2")
    _1 = getattr(self, "1")
    _0 = getattr(self, "0")
    _8 = (_1).forward((_0).forward(argument_1, ), )
    _9 = (_4).forward((_3).forward((_2).forward(_8, ), ), )
    _10 = (_7).forward((_6).forward((_5).forward(_9, ), ), )
    return _10
