class InvertedResidual(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.container.___torch_mangle_64.Sequential
  def forward(self: __torch__.ptfile.mobilenetv2_pytorch.models.imagenet.mobilenetv2_base.___torch_mangle_65.InvertedResidual,
    argument_1: Tensor) -> Tensor:
    conv = self.conv
    return (conv).forward(argument_1, )
